#include <stdint.h>
#include <stdlib.h>
#include <assert.h>

signed main(void)
  {
    static_assert(sizeof(unsigned) > sizeof(uint64_t), "unsigned large enough.");
    return EXIT_SUCCESS;
  }
