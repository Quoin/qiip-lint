/**
 * @file
 *
 * Example of how to suspend curses. This works with both POSIX and AIX
 * extended curses.
 *
 * @warning There is @em no error handling here. This is not production ready.
 *
 * To compile on Linux:
 *
 * @code
 *   $ clang-7 -x'c' -std='c11' -W'everything' -f'lto' -f'visibility=hidden' -f'sanitize=undefined' -f'sanitize=address' -f'sanitize=cfi' -O'2' -g'gdb' -g'3' -o resource resource.c -lcurses
 * @endcode
 */

#include <curses.h>
#include <stdlib.h>
#include <stddef.h>
#include <assert.h>


signed main(void) __attribute__((nothrow));


signed main(void)
  {
    signed result = EXIT_SUCCESS;

    WINDOW * const scr = initscr();
    assert((NULL != scr) && (stdscr == scr));

    noecho();
    
    {
      char const msg[] = "hello, world - before system()...";
      mvwaddstr(scr, 10, 10, msg);
      wgetch(scr);
    }


    /* Suspend curses and restore normal terminal mode. */
    def_prog_mode();
    endwin();

    /* proceed in normal terminal mode - system() */
    {
      system("/usr/bin/vi");
    }

    /* Resume curses. */
    {
      reset_prog_mode();
      wrefresh(scr);
    }

    {
      char const msg[] = "after system().";
      mvwaddstr(scr, 10, 44, msg);
      wgetch(scr);
    }

    /* Terminate curses and restore normal terminal mode. */
    {
      endwin();
    }

    return result;
  }
