/**
 * Compile with:
 *
 * clang++-7 -std='c++2a' -stdlib='libc++' -W'everything' -W'no-unused-parameter' -W'no-c++98-compat' -W'no-zero-as-null-pointer-constant' -O'2' -g'3' -f'sanitize=address' -f'sanitize=undefined' -o attributes attributes.cpp
 */


#include <stdlib.h>
#include <assert.h>


/* Declaration */
void times2 [[gnu::nonnull]] (unsigned * arg);


/* Definition */
void times2(unsigned * const arg)
  {
    assert(NULL != arg);
    *arg = 2U * (*arg);
  }


signed main(signed const argc, char * argv[])
  {
    unsigned good = 1U;
    unsigned * const bad = NULL;

    times2(&good);
    times2(bad);

    return EXIT_SUCCESS;
  }
