/*
 * Example of C11 array parameter annotations.
 *
 * Compile with the following. You should get a warning about "too_small". The
 * undefined behavior sanitizer will catch the memory address error.
 *
 * $ clang -std='c18' -W'everything' -O'2' -g'3' -f'sanitize=address' -f'sanitize=undefined' -o array_parameter array_parameter.c
 */

#include <stdio.h>
#include <stdlib.h>


#define SIZE_MIN 5


unsigned accumulate(unsigned const arg[static SIZE_MIN]);

signed main(void);


unsigned accumulate(unsigned const arg[const restrict static SIZE_MIN])
  {
    unsigned result = 0U;

    for (size_t i = 0U; SIZE_MIN > i; ++i)
      {
        result += arg[i];
      }

    return result;
  }


signed main(void)
  {
    unsigned const too_small[] = {0U, 1U, 2U, 3U};
    unsigned const just_right[] = {0U, 1U, 2U, 3U, 4U};
    unsigned const too_big[] = {0U, 1U, 2U, 3U, 4U, 5U};

    printf("too_small=\"%u\".\n", accumulate(too_small));
    printf("just_right=\"%u\".\n", accumulate(just_right));
    printf("too_big=\"%u\".\n", accumulate(too_big));

    return EXIT_SUCCESS;
  }
