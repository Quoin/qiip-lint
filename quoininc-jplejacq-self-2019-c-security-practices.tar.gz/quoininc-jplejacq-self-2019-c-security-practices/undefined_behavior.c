/*
 * To compile on Linux:
 *
 * @code
 *   $ clang-7 -x'c' -std='c11' -W'everything' -f'lto' -f'visibility=hidden' -f'sanitize=undefined' -f'sanitize=address' -f'sanitize=cfi' -O'2' -g'gdb' -g'3' -o undefined_behavior undefined_behavior.c
 * @endcode
 */

#include <curses.h>
#include <stdlib.h>
#include <stddef.h>
#include <assert.h>


void handle_account_type(unsigned type);


enum account
  {
     account_checking = 10,
     account_saving
  };

typedef enum account account;

void handle_account_type_safe(account type);



void handle_account_type(unsigned const type)
  {
    assert((10 <= type) && (11 >= type));
    /* ... */
  }

void handle_account_type_safe(account const type)
  {
    /* No need for run time assert. */
    /* ... */
  }


signed main(void)
  {
    handle_account_type(0);
    handle_account_type_safe(account_checking);
    return EXIT_SUCCESS;
  }
