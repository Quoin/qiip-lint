/**
 * @file
 *
 * Example of how to suspend curses. This works with both POSIX and AIX
 * extended curses.
 *
 * @warning There is @em no error handling here. This is not production ready.
 *
 * To compile on Linux:
 *
 * @code
 *   $ clang-7 -x'c' -std='c11' -W'everything' -f'lto' -f'visibility=hidden' -f'sanitize=undefined' -f'sanitize=address' -f'sanitize=cfi' -O'2' -g'gdb' -g'3' -o resource resource.c -lcurses
 * @endcode
 */

#include <curses.h>
#include <stdlib.h>
#include <stddef.h>
#include <assert.h>


signed main(void) __attribute__((nothrow));


signed main(void)
  {
    signed result = EXIT_SUCCESS;

    WINDOW * const scr = initscr();
    if ((NULL == scr) || (stdscr != scr))
      {
        goto return_clean;
      }
    
    {
      signed const rc = noecho();
      if (OK != rc)
        {
          goto return_endwin
        }
    }
    
    {
      char const msg[] = "hello, world - before system()...";
      mvwaddstr(scr, 10, 10, msg);
      wgetch(scr);
    }


    /* Suspend curses and restore normal terminal mode. */
    def_prog_mode();
    endwin();

    /* proceed in normal terminal mode - system() */
    {
      signed const rc = system("/usr/bin/vi");
      if (0 != rc)
        {
          goto return_reset;
        }
    }

    /* Resume curses. */
    {
      {
        signed const rc = reset_prog_mode();
        if (OK != rc)
          {
            goto return_endwin;
          }
      }

      {
        signed const rc = wrefresh(scr);
        if (OK != rc)
          {
            goto return_endwin;
          }
      }
    }

    {
      char const msg[] = "after system().";
      mvwaddstr(scr, 10, 44, msg);
      wgetch(scr);
    }

    /* Terminate curses and restore normal terminal mode. */
    {
      (void)endwin();
      goto return_success;
    }



    return_reset:
      {
        (void)reset_prog_mode();
        (void)wrefresh(scr);
      }
      
    return_endwin:
      {
        (void)endwin();
      }

    return_failure:
      {
        result = EXIT_FAILURE;
      }

    return_success:


    return result;
  }
