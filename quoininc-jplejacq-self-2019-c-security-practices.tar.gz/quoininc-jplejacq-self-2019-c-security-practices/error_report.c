#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>


signed main(signed const argc, char * argv[const])
  {
    /* Impossible to tell if an error occurred. */
    {
      signed const value = atoi(argv[1]);
      printf("you entered the number \"%d\".\n", value);
    }

    /* Can detemine an error occurred but it's a disaster. */
    {
      signed const base = 10;
      char * end = NULL;
      errno = 0;
      signed long const value = strtol(argv[1], &end, base);
 
      if (end == argv[1])
        {
          fprintf(stderr, "%s: not a decimal number.\n", argv[1]);
        }
      else if ('\0' != *end)
        {
          fprintf(stderr, "%s: extra characters at end of input: %s.\n", argv[1], end);
        }
      else if (((LONG_MIN == value) || (LONG_MAX == value)) && (ERANGE == errno))
        {
          fprintf(stderr, "%s out of range of type long\n", argv[1]);
        }
      else if (value > INT_MAX)
        {
          fprintf(stderr, "%ld greater than INT_MAX\n", value);
        }
      else if (value < INT_MIN)
        {
          fprintf(stderr, "%ld less than INT_MIN\n", value);
        }
      else
        {
          printf("you entered the number \"%ld\".\n", value);
        }
    }

    /* Are you sure this is OK? */
    {
      char buf[20 + 1] = "tty=";
      strcat(buf, getenv("TTY"));
      printf("environment variable %s\n", buf);
    }


    return EXIT_SUCCESS;
  }
