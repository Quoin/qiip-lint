/**
 * Compile with:
 *
 * clang-7 -std='c17' -D'_POSIX_C_SOURCE=200809L' -W'everything' -W'error=unused-result' -O'2' -g'3' -f'sanitize=address' -f'sanitize=undefined' -o error_recommendation error_recommendation.c
 */


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>


/* C11 typedef */
typedef signed errno_t;


/**
 * Wrapper for POSIX system() to simplify error handling.
 *
 * This function simplifies the error handling for the POSIX function system().
 * Normally a complicated set of macros are required to determine if the command
 * was executed and its exit status.
 *
 * Instead, you need to only use the following idiom:
 *
 * @code{.c}
 *    errno_t const rc = qi_system("command");
 *    if (0 == rc) {
 *       printf("command succeeded.\n");
 *    } else {
 *       fprintf(stderr, "Failure executing command.\n");
 *    }
 * @endcode
 *
 * If you need more detail on why the program failed to execute, use the
 * following:
 *
 * @code{.c}
 *    errno_t const rc = qi_system("command");
 *    if (0 == rc) {
 *       printf("command succeeded.\n");
 *    } else (0 < rc) {
 *       fprintf(stderr, "command executed but returned failure.\n");
 *    } else {
 *       fprintf(stderr, "Failure executing command.\n");
 *    }
 * @endcode
 *
 * @param[in] command to execute. Non-null NTCTS, ownership is not transferred.
 * @return 0-255 on success with specific value returned by command, negative
 *    value on failure.
 *    -1 unknown, unable to determine exit status of child process.
 *    -2 Failure, unknown reason.
 *    -3 Failure, unable to create child process.
 *    -4 Failure, unable to executing shell/command in child process.
 *    -5 Failure, child terminated by signal.
 *
 * @see http://pubs.opengroup.org/onlinepubs/9699919799/functions/system.html
 */
errno_t qi_system(char const * command) __attribute((nonnull, warn_unused_result));


errno_t qi_system(char const * const restrict command)
  {
    errno_t result = 0;
    errno = 0;
    signed const rc = system(command);

    if (-1 != rc)
      {
        signed const status = WEXITSTATUS(rc);
        if (127 != status)
          {
            if (WIFEXITED(rc))
              {
                /* Success. */
                result = status;
              }
            else if (WIFSIGNALED(rc))
              {
                /* Failure, child terminated by signal. */
                result = -5;
              }
            else
              {
                /* Failure, unknown reason. */
                result = -2;
              }
          }
        else
          {
            /* Failure, unable to executing shell in child process. */
            result = -4;
          }
      }
    else if ((-1 == rc) && (ECHILD == errno))
      {
        /* Unknown, unable to determine exit status of child process. */
        result = -1;
      }
    else
      {
       /* Failure, unable to create child process. */
       result = -3;
      }

    return result;
  }


signed main(signed const argc, char * argv[const])
  {
    signed result = EXIT_SUCCESS;

    errno_t const rc = qi_system(argv[1]);
    if (0 != rc)
      {
        fprintf(stderr, "Failure executing command. command=\"%s\" error=\"%d\".\n", argv[1], rc);
        result = EXIT_FAILURE;
      }

    qi_system(argv[2]);

    return result;
  }
